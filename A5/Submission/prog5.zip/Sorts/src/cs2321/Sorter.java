package cs2321;

public interface Sorter<E> {
	public void sort(E[] array);
}
