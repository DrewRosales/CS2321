package cs2321;

public class HeapPQSort<K extends Comparable<K>> extends PQSort<K> implements Sorter<K> {
	
	public void sort(K[] array) {
		// TODO Auto-generated method stub

	}

}
