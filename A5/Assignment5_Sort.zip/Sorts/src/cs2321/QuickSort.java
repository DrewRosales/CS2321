package cs2321;

public class QuickSort<E extends Comparable<E>> implements Sorter<E> {

	public void sort(E[] array) {
		// TODO Auto-generated method stub

	}
}
