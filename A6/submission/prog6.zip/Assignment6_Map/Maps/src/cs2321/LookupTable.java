package cs2321;

import net.datastructures.*;

public class LookupTable<K extends Comparable<K>, V> extends AbstractMap<K,V> implements SortedMap<K, V> {
	
	/* Use Sorted ArrayList for the Underlying storage for the map of entries.
	 * 
	 */
	private ArrayList<mapEntry<K,V>> table = new ArrayList<>(); 
	
	public LookupTable(){
		
	}
	
	@Override
	public int size() {
		return table.size();
	}

	@Override
	public boolean isEmpty() {
		return size()==0;
	}
	public int findIndex(K key, int low, int high) {
		if(high < low) {
			return high + 1;
		}
		int mid = (high+low)/2;
		if(key.compareTo(table.get(mid).getKey()) == 0) {
			return mid;
		} else if(key.compareTo(table.get(mid).getKey()) < 0) {
			return findIndex(key, low, mid -1);
		} else {
			return findIndex(key, mid + 1,high);
		}
	}
	private int findIndex(K key) {
		int foo = findIndex(key, 0, table.size()-1);
 		return foo;
	}
	@Override
	public V get(K key) {
		int i = findIndex(key);
		if(i==size() || (key.compareTo(table.get(i).getKey()) != 0))
			return null;
		return table.get(i).getValue();
	}

	@Override
	public V put(K key, V value) {
		int i = findIndex(key);
		if(i < size() && (key.compareTo(table.get(i).getKey())== 0)) {
			V oldValue = get(key);
			table.get(i).setValue(value);
			return oldValue;
		}
		table.add(i, new mapEntry<K,V> (key, value));
		return null;
	}

	@Override
	public V remove(K key) {
		int i = findIndex(key);
		if(i == size() || (key.compareTo(table.get(i).getKey()) !=0)){
			return null;
		}
		return table.remove(i).getValue();
	}
	
	private Entry<K,V> validEntry(int i){
		if(i<0 || i>=table.size()) {
			return null;
		}
		return table.get(i);
	}


	@Override
	public Iterable<Entry<K, V>> entrySet() {
		return snapshot(0,null);
	}

	@Override
	public Entry<K, V> firstEntry() {
		return validEntry(0);
	}

	@Override
	public Entry<K, V> lastEntry() {
		return validEntry(table.size() - 1);
	}

	@Override
	public Entry<K, V> ceilingEntry(K key)  {
		return validEntry(findIndex(key));
	}

	@Override
	public Entry<K, V> floorEntry(K key)  {
		int i = findIndex(key);
		if(i == size() || !key.equals(table.get(i).getKey()))
			i--;
		return validEntry(i);
	}

	@Override
	public Entry<K, V> lowerEntry(K key) {
		return validEntry(findIndex(key) -1);
	}

	@Override
	public Entry<K, V> higherEntry(K key) {
		int i = findIndex(key);
		if(i < size() && key.equals(table.get(i).getKey())) {
			i++;
		}
		return validEntry(i);
	}
	private Iterable<Entry<K,V>> snapshot(int start, K stop){
		ArrayList<Entry<K,V>> buffer = new ArrayList<>();
		int i = start;
		while(i<table.size() && (stop == null || stop.compareTo(table.get(i).getKey()) >0)) {
			buffer.addLast(table.get(i++));
		}
		return buffer;
	}
	@Override
	public Iterable<Entry<K, V>> subMap(K fromKey, K toKey){
		return snapshot(findIndex(fromKey), toKey);
	}


}
