package cs2321;

import net.datastructures.*;

public class HashMap<K, V> extends AbstractMap<K,V> implements Map<K, V> {
	
	/* Use Array of UnorderedMap<K,V> for the Underlying storage for the map of entries.
	 * 
	 */
	private UnorderedMap<K,V>[]  table;
	int 	size;  // number of mappings(entries) 
	int 	capacity; // The size of the hash table. 
	int     DefaultCapacity = 17; //The default hash table size
	
	/* Maintain the load factor <= 0.75.
	 * If the load factor is greater than 0.75, 
	 * then double the table, rehash the entries, and put then into new places. 
	 */
	double  loadfactor= 0.75;  
	
	@TimeComplexity("O(1)")
	protected void createTable() {
		table = (UnorderedMap<K,V>[]) new UnorderedMap[capacity];
	}
	/**
	 * Constructor that takes a hash size
	 * @param hashtable size: the number of buckets to initialize 
	 */
	public HashMap(int hashtablesize) {
		capacity = hashtablesize;
		table = (UnorderedMap<K,V>[]) new UnorderedMap[hashtablesize];
	}
	
	/**
	 * Constructor that takes no argument
	 * Initialize the hash table with default hash table size: 17
	 */
	public HashMap() {
		capacity = DefaultCapacity;
		table = (UnorderedMap<K,V>[]) new UnorderedMap[capacity];
	}
	
	/* This method should be called by map an integer to the index range of the hash table 
	 */
	@TimeComplexity("O(1)")
	private int hashValue(K key) {
		return Math.abs(key.hashCode()) % capacity;
	}
	
	@TimeComplexity("O(n)")
	private void resize(int newCap) {
		ArrayList<Entry<K,V>> buffer = new ArrayList<>(size);
		for(Entry<K,V> e : entrySet()) {
			buffer.addLast(e);
		}
		capacity = newCap;
		createTable();
		size=0;
		for(Entry<K,V> e: buffer) {
			put(e.getKey(), e.getValue());
		}
	}
	/*
	 * The purpose of this method is for testing if the table was doubled when rehashing is needed. 
	 * Return the the size of the hash table. 
	 * It should be 17 initially, after the load factor is more than 0.75, it should be doubled.
	 */
	@TimeComplexity("O(n)")
	public int tableSize() {
		double lf = size/capacity;
		if(lf > loadfactor) {
			resize(capacity*2);
		}
		return size;
	}
	
	@TimeComplexity("O(1)")
	@Override
	public int size() {
		return size;
	}

	@TimeComplexity("O(1)")
	@Override
	public boolean isEmpty() {
		return size == 0;
	}
	
	@TimeComplexity("O(1)")
	protected V bucketGet(int h, K k) {
		UnorderedMap<K,V> bucket = table[h];
		if(bucket == null) {
			return null;
		}
		return bucket.get(k);
	}
	
	@TimeComplexity("O(1)")
	@Override
	public V get(K key) {
		return bucketGet(hashValue(key), key);
	}
	
	@TimeComplexity("O(1)")
	protected V bucketPut(int h, K k, V v) {
		UnorderedMap<K,V> bucket = table[h];
		if(bucket == null)
			bucket = table[h] = new UnorderedMap<>();
		int oldSize = bucket.size();
		V answer = bucket.put(k,v);
		size += (bucket.size() - oldSize);
		return answer;
	}
	@Override
	@TimeComplexity("O(1)")
	public V put(K key, V value) {
		V answer = bucketPut(hashValue(key), key, value);
		tableSize();
		return answer;
	}
	@TimeComplexity("O(1)")
	protected V bucketRemove(int h, K k) {
		UnorderedMap<K,V> bucket = table[h];
		if(bucket == null)
			return null;
		int oldSize = bucket.size();
		V answer = bucket.remove(k);
		size -= (oldSize - bucket.size());
		return answer;
	}
	@Override
	@TimeComplexity("O(1)")
	public V remove(K key) {
		return bucketRemove(hashValue(key), key);
	}

	@Override
	@TimeComplexity("O(n)")
	public Iterable<Entry<K, V>> entrySet() {
		ArrayList<Entry<K,V>> buffer = new ArrayList<>();
		for(int i=0; i<capacity; i++) {
			if(table[i] != null)
				for(Entry<K,V> entry: table[i].entrySet()) {
					buffer.addLast(entry);
				}
		}
		return buffer;
	}
	

}
