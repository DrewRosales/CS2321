package cs2321;
import java.util.Iterator;

import net.datastructures.*;
	

public class LinkedBinaryTree<E> implements BinaryTree<E>{
	
	protected static class Node<E> implements Position<E>{

		private E element;
		private Node<E> parent;
		private Node<E> left;
		private Node<E> right;
		
		public Node(E e, Node<E> prev, Node<E> leftChild, Node<E> rightChild) {
			element = e;
			parent = prev;
			left = leftChild;
			right = rightChild;
		}
		
		@TimeComplexity("O(1)")
		public Node<E> getParent() {
			return parent;
		}
		
		@TimeComplexity("O(1)")
		public void setParent(Node<E> parent) {
			this.parent = parent;
		}
		
		@TimeComplexity("O(1)")
		public Node<E> getLeft() {
			return left;
		}
		
		@TimeComplexity("O(1)")
		public void setLeft(Node<E> left) {
			this.left = left;
		}
		
		@TimeComplexity("O(1)")
		public Node<E> getRight() {
			return right;
		}
		@TimeComplexity("O(1)")
		public void setRight(Node<E> right) {
			this.right = right;
		}
		
		@TimeComplexity("O(1)")
		@Override
		public E getElement() throws IllegalStateException {
			return element;
		}
		
		@TimeComplexity("O(1)")
		public void setElement(E element) {
			this.element = element;
		}

	}
	@TimeComplexity("O(1)")
	protected Node<E> createNode(E e, Node<E> parent, Node<E>left, Node<E>right){
		return new Node<E>(e, parent, left, right);
	}
	@TimeComplexity("O(1)")
	protected Node<E> root = null;
	private int size =0;
	
	@Override
	public Position<E> root() {
		return root;
	}
	
	public  LinkedBinaryTree( ) {
		
	}
	
	@TimeComplexity("O(1)")
	protected Node<E> validate(Position<E> p) throws IllegalArgumentException{
		if(!(p instanceof Node)) {
			throw new IllegalArgumentException("Not valid position");
		}
		Node<E> node = (Node<E>) p;
		if(node.getParent() == node) {
			throw new IllegalArgumentException("p is not part of the tree");
		}
		return node;
	}
	@TimeComplexity("O(1)")
	@Override
	public Position<E> parent(Position<E> p) throws IllegalArgumentException {
		Node<E> node = validate(p);
		return node.getParent();
	}

	@TimeComplexity("O(n)")
	@Override
	public Iterable<Position<E>> children(Position<E> p) throws IllegalArgumentException {
		ArrayList<Position<E>> snapshot = new ArrayList<>(2);
		if(left(p) != null) {
			snapshot.addLast(left(p));
		}
		if(right(p) != null) {
			snapshot.addLast(right(p));
		}
		return null;
	}

	@TimeComplexity("O(1)")
	@Override
	/* count only direct child of the node, not further descendant. */
	public int numChildren(Position<E> p) throws IllegalArgumentException {
		int count=0;
		Node<E> parent = validate(p);
		if(parent.getLeft() != null) {
			count++;
		}
		if(parent.getRight() != null) {
			count++;
		}
		return count;
	}

	@TimeComplexity("O(1)")
	@Override
	public boolean isInternal(Position<E> p) throws IllegalArgumentException {
		Node<E> e = validate(p);
		return numChildren(e) > 0;
	}

	@TimeComplexity("O(1)")
	@Override
	public boolean isExternal(Position<E> p) throws IllegalArgumentException {
		Node<E> e = validate(p);
		return numChildren(e) == 0;
	}

	@TimeComplexity("O(1)")
	@Override
	public boolean isRoot(Position<E> p) throws IllegalArgumentException {
		Node<E> e = validate(p);
		return e == root();
	}

	@TimeComplexity("O(1)")
	@Override
	public int size() {
		return size;
	}

	@TimeComplexity("O(1)")
	@Override
	public boolean isEmpty() {
		return size == 0;
	}

	@TimeComplexity("O(n)")
	private class ElementIterator implements Iterator<E>{
		Iterator<Position<E>> posIterator = positions().iterator();

		@Override
		public boolean hasNext() {
			return posIterator.hasNext();
		}

		@Override
		public E next() {
			return posIterator.next().getElement();
		}
		
	}
	
	@TimeComplexity("O(n)")
	@Override
	public Iterator<E> iterator() {
		return new ElementIterator();
	}

	@TimeComplexity("O(n)")
	private void preorderSubtree(Position<E> p, ArrayList<Position<E>> snapshot) {
		snapshot.addLast(p);
		for(Position<E> c : children(p)) {
			preorderSubtree(c,snapshot);
		}
	}
	
	@TimeComplexity("O(n)")
	public Iterable<Position<E>> preorder(){
		ArrayList<Position<E>> snapshot = new ArrayList<>();
		if(!isEmpty()) {
			preorderSubtree(root(), snapshot);
		}
		return snapshot;
	}
	
	@TimeComplexity("O(n)")
	@Override
	public Iterable<Position<E>> positions() {
		return preorder();
	}

	@TimeComplexity("O(1)")
	@Override
	public Position<E> left(Position<E> p) throws IllegalArgumentException {
		Node<E> node = validate(p);
		return node.getLeft();
	}

	@TimeComplexity("O(1)")
	@Override
	public Position<E> right(Position<E> p) throws IllegalArgumentException {
		Node<E> node = validate(p);
		return node.getRight();
	}

	@TimeComplexity("O(1)")
	@Override
	public Position<E> sibling(Position<E> p) throws IllegalArgumentException {
		Position<E> parent = parent(p);
		if(parent == null) {
			return null;
		}
		if(parent == left(parent)) {
			return right(parent);
		} else {
			return left(parent);
		}
		
	}
	
	
	@TimeComplexity("O(1)")
	/* creates a root for an empty tree, storing e as element, and returns the 
	 * position of that root. An error occurs if tree is not empty. 
	 */
	public Position<E> addRoot(E e) throws IllegalStateException {
		if(!isEmpty()) {
			throw new IllegalStateException("Tree is not empty");
		}
		root = createNode(e,null,null,null);
		size = 1;
		return root;
	}
	
	@TimeComplexity("O(1)")
	/* creates a new left child of Position p storing element e, return the left child's position.
	 * If p has a left child already, throw exception IllegalArgumentExeption. 
	 */
	public Position<E> addLeft(Position<E> p, E e) throws IllegalArgumentException {
		Node<E> parent = validate(p);
		if(parent.getLeft() != null) {
			throw new IllegalArgumentException("Left child exists");
		}
		Node<E> child = createNode(e, parent,null,null);
		parent.setLeft(child);
		size++;
		return child;
	}

	@TimeComplexity("O(1)")
	/* creates a new right child of Position p storing element e, return the right child's position.
	 * If p has a right child already, throw exception IllegalArgumentExeption. 
	 */
	public Position<E> addRight(Position<E> p, E e) throws IllegalArgumentException {
		Node<E> parent = validate(p);
		if(parent.getRight() != null) {
			throw new IllegalArgumentException("Right child exists");
		}
		Node<E> child = createNode(e, parent, null, null);
		parent.setRight(child);
		size++;
		return child;
	}
	
	@TimeComplexity("O(n)")
	/* Attach trees t1 and t2 as left and right subtrees of external Position. 
	 * if p is not external, throw IllegalArgumentExeption.
	 */
	public void attach(Position<E> p, LinkedBinaryTree<E> t1, LinkedBinaryTree<E> t2)
			throws IllegalArgumentException {
		Node<E> node = validate(p);
		if(isInternal(p)) {
			throw new IllegalArgumentException("p must be a leaf");
		}
		size += t1.size() + t2.size();
		if(!t1.isEmpty()) {
			t1.root.setParent(node);
			node.setLeft(t1.root);
			t1.root = null;
			t1.size = 0;
		}
		if(!t2.isEmpty()) {
			t2.root.setParent(node);
			node.setRight(t2.root);
			t2.root = null;
			t2.size  = 0;
		}
	
	}
	
	@TimeComplexity("O(1)")
	public E remove(Position<E> p) {
		Node<E> node = validate(p);
		if(numChildren(p)==2) {
			throw new IllegalArgumentException("p has two children");
		}
		Node<E> child = (node.getLeft() != null ? node.getLeft():node.getRight());
		if(child != null) {
			child.setParent(node.getParent());
		}
		if(node == root){
			root = child;
		}else {
			Node<E> parent = node.getParent();
			if(node == parent.getLeft()) {
				parent.setLeft(child);
			}else {
				parent.setRight(child);
			}
		}
		
		size--;
		E temp = node.getElement();
		node.setElement(null);
		node.setLeft(null);
		node.setRight(null);
		node.setParent(null);
		
		return temp;
	}
	
	@TimeComplexity("O(1)")
	public E set(Position<E> p, E e) throws IllegalArgumentException{
		Node<E> node = validate(p);
		E temp = node.getElement();
		node.setElement(e);
		return temp;
	}
}
