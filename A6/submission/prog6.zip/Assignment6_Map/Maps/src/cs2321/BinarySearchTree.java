package cs2321;

import net.datastructures.Entry;
import net.datastructures.SortedMap;
import net.datastructures.*;


public class BinarySearchTree<K extends Comparable<K>,V> extends AbstractMap<K,V> implements SortedMap<K,V> {
	
	/* all the data will be stored in tree*/
	LinkedBinaryTree<Entry<K,V>> tree;
	int size;  //the number of entries (mappings)
	
	/* 
	 * default constructor
	 */
	public BinarySearchTree() {
		tree = new LinkedBinaryTree<Entry<K,V>>();
		tree.addRoot(null);
	}
	
	/* 
	 * Return the tree. The purpose of this method is purely for testing. 
	 * You don't need to make any change. Just make sure to use object tree to store your entries. 
	 */
	public LinkedBinaryTree<Entry<K,V>> getTree() {
		return tree;
	}
	@TimeComplexity("O(1)")
	@Override
	public int size(){
		// TODO Auto-generated method stub
		return (tree.size() - 1)/2;
	}
	
	@TimeComplexity("O(1)")
	private void expandExternal(Position<Entry<K,V>> p, Entry<K,V> entry) {
		tree.set(p, entry);
		tree.addLeft(p, null);
		tree.addRight(p, null);
	}
	
	@TimeComplexity("O(n)")
	private Position<Entry<K,V>> treeSearch(Position<Entry<K,V>> p, K key){
		//O(height) but bounded by n
		if(tree.isExternal(p)) {
			return p;
		}
		int comp = key.compareTo(p.getElement().getKey());
		if(comp == 0) {
			return p;
		} else if(comp < 0) {
			return treeSearch(tree.left(p), key);
		} else {
			return treeSearch(tree.right(p), key);
		}
	}
	@TimeComplexity("O(1)")
	protected Position<Entry<K,V>> root() {
		return tree.root();
	}
	
	@TimeComplexity("O(1)")
	protected boolean checkKey(K key) throws IllegalArgumentException{
		try {
			return(key.compareTo(key) == 0);
		}catch (ClassCastException e) {
			throw new IllegalArgumentException("Incompatible Key");
		}
	}
	
	@TimeComplexity("O(n)")
	@Override
	public V get(K key) {
		checkKey(key);
		Position<Entry<K,V>> p  = treeSearch(root(), key);
		if(tree.isExternal(p)) {
			return null;
		}
		return p.getElement().getValue();
	}

	@TimeComplexity("O(n)")
	@Override
	public V put(K key, V value) {
	    checkKey(key);                          // may throw IllegalArgumentException
	    Entry<K,V> newEntry = new mapEntry<>(key, value);
	    Position<Entry<K,V>> p = treeSearch(root(), key);
	    if (tree.isExternal(p)) {                    // key is new
	      expandExternal(p, newEntry);
	      return null;
	    } else {                                // replacing existing key
	      V old = p.getElement().getValue();
	      tree.set(p, newEntry);
	      return old;
	    }
	}

	@TimeComplexity("O(n)")
	  protected Position<Entry<K,V>> treeMin(Position<Entry<K,V>> p) {
		    Position<Entry<K,V>> walk = p;
		    while (tree.isInternal(walk))
		      walk = tree.left(walk);
		    return tree.parent(walk);
		  }
	@TimeComplexity("O(n)")
	protected Position<Entry<K,V>> treeMax(Position<Entry<K,V>> p){
		Position<Entry<K,V>> walk = p;
		while(tree.isInternal(walk)) {
			walk = tree.right(walk);
		}
		return tree.parent(walk);
	}
	
	@TimeComplexity("O(n)")
	@Override
	public V remove(K key) {
		checkKey(key);
		Position<Entry<K,V>> p  = treeSearch(root(), key);
		if(tree.isExternal(p)) {
			return null;
		} else {
			V oldValue = p.getElement().getValue();
			if(tree.isInternal(tree.left(p)) && tree.isInternal(tree.right(p))){
				Position<Entry<K,V>> replacement = treeMax(tree.left(p));
				tree.set(p, replacement.getElement());
				p = replacement;
			}
			
		Position<Entry<K,V>> leaf = (tree.isExternal(tree.left(p)) ? tree.left(p) : tree.right(p));		
		Position<Entry<K,V>> sib = tree.sibling(leaf);
		tree.remove(leaf);
		tree.remove(p);
		tree.remove(sib);
		return oldValue;
		}
	}

	@TimeComplexity("O(1)")
	@Override
	public Entry<K, V> firstEntry() {
		if (isEmpty()) return null;
	    return treeMin(root()).getElement();
	}

	@TimeComplexity("O(1)")
	@Override
	public Entry<K, V> lastEntry() {
		if(isEmpty()) {
			return null;
		}
		return treeMax(root()).getElement();
	}

	@TimeComplexity("O(1)")
	@Override
	public Entry<K, V> ceilingEntry(K key) {
		checkKey(key);
	    Position<Entry<K,V>> p = treeSearch(root(), key);
	    if (tree.isInternal(p)) return p.getElement();
	    while (!tree.isRoot(p)) {
	      if (p == tree.left(tree.parent(p)))
	        return tree.parent(p).getElement();
	      else
	        p = tree.parent(p);
	    }
	    return null;                    
	}

	@TimeComplexity("O(1)")
	@Override
	public Entry<K, V> floorEntry(K key)  {
		checkKey(key);
		Position<Entry<K,V>> p = treeSearch(root(), key);
		if(tree.isInternal(p)) {
			return p.getElement();
		}
		while(!tree.isRoot(p)) {
			if(p == tree.right(tree.parent(p))) {
				return tree.parent(p).getElement();
			}else {
				p = tree.parent(p);
			}
		}
		return null;
	}

	@TimeComplexity("O(1)")
	@Override
	public Entry<K, V> lowerEntry(K key) {
		checkKey(key);
		Position<Entry<K,V>> p = treeSearch(root(), key);
		if(tree.isInternal(p) && tree.isInternal(tree.left(p))) {
			return treeMax(tree.left(p)).getElement();
		}
		while(!tree.isRoot(p)) {
			if(p == tree.right(tree.parent(p))) {
				return tree.parent(p).getElement();
			}else {
				p = tree.parent(p);
			}
		}
		return null;
	}

	@TimeComplexity("O(1)")
	@Override
	public Entry<K, V> higherEntry(K key){
		checkKey(key);                              
	    Position<Entry<K,V>> p = treeSearch(root(), key);
	    if (tree.isInternal(p) && tree.isInternal(tree.right(p)))
	      return treeMin(tree.right(p)).getElement();
	    while (!tree.isRoot(p)) {
	      if (p == tree.left(tree.parent(p)))
	        return tree.parent(p).getElement();
	      else
	        p = tree.parent(p);
	    }
	    return null;                 
	}
	
	@TimeComplexity("O(n)")
	private void inorderSubtree(Position<Entry<K,V>> p, ArrayList<Position<Entry<K,V>>> snapshot) {
	    if (tree.left(p) != null)
	      inorderSubtree(tree.left(p), snapshot);
	    snapshot.addLast(p);
	    if (tree.right(p) != null)
	      inorderSubtree(tree.right(p), snapshot);
	  }

	  /**
	   * Returns an iterable collection of positions of the tree, reported in inorder.
	   * @return iterable collection of the tree's positions reported in inorder
	   */
	
	@TimeComplexity("O(n)")
	  public Iterable<Position<Entry<K,V>>> inorder() {
	    ArrayList<Position<Entry<K,V>>> snapshot = new ArrayList<>();
	    if (!isEmpty())
	      inorderSubtree(root(), snapshot);   // fill the snapshot recursively
	    return snapshot;
	  }
	
		@TimeComplexity("O(n)")
	  @Override
	  public Iterable<Entry<K,V>> entrySet() {
	    ArrayList<Entry<K,V>> buffer = new ArrayList<>(size());
	    for (Position<Entry<K,V>> p : inorder())
	      if (tree.isInternal(p)) buffer.addLast(p.getElement());
	    return buffer;
	  }
	  
		@TimeComplexity("O(n)")
	  private void subMapRecurse(K fromKey, K toKey, Position<Entry<K,V>> p,
			  ArrayList<Entry<K,V>> buffer) {
		  if (tree.isInternal(p))
			  if (p.getElement().getKey().compareTo(fromKey) < 0)
				  subMapRecurse(fromKey, toKey, tree.right(p), buffer);
			  else {
				  subMapRecurse(fromKey, toKey, tree.left(p), buffer);
				  if (p.getElement().getKey().compareTo(toKey) < 0) {
					  buffer.addLast(p.getElement());
					  subMapRecurse(fromKey, toKey, tree.right(p), buffer); // right subtree as well
				  }
			  }
	  }
	  
	@TimeComplexity("O(n)")
	@Override
	public Iterable<Entry<K, V>> subMap(K fromKey, K toKey)
			throws IllegalArgumentException {
	    checkKey(fromKey);
	    checkKey(toKey);
	    ArrayList<Entry<K,V>> buffer = new ArrayList<>(size());
	    if (fromKey.compareTo(toKey) < 0)
	      subMapRecurse(fromKey, toKey, root(), buffer);
	    return buffer;
	}

	@TimeComplexity("O(1)")
	@Override
	public boolean isEmpty() {
		return size() ==0;
	}

}
