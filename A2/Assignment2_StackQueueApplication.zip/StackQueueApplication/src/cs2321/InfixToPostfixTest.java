package cs2321;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class InfixToPostfixTest {

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testConvert1() {
		fail("Not yet implemented"); // TODO
	}
	
	@Test
	public void testConvert2() {
		fail("Not yet implemented"); // TODO
	}

	@Test
	public void testConvert3() {
		fail("Not yet implemented"); // TODO
	}
	
	@Test
	public void testConvert4() {
		fail("Not yet implemented"); // TODO
	}
	
	@Test
	public void testConvert5() {
		fail("Not yet implemented"); // TODO
	}
	
	@Test
	public void testConvert6() {
		fail("Not yet implemented"); // TODO
	}
	
	@Test
	public void testConvert7() {
		fail("Not yet implemented"); // TODO
	}
	
	@Test
	public void testConvert8() {
		fail("Not yet implemented"); // TODO
	}
}
