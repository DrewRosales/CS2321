package cs2321;

import java.util.Comparator;

import net.datastructures.*;
/**
 * A PriorityQueue based on an ordered Doubly Linked List. 
 * 
 * Course: CS2321 Section ALL
 * Assignment: #3
 * @Drew Rosales
 */

public class OrderedPQ<K,V> implements PriorityQueue<K,V> {
	private int size = 0;
	private Comparator<K> comparator;
	DoublyLinkedList<Entry<K,V>> PQ = new DoublyLinkedList<>();
	
	public OrderedPQ() {
		comparator = new DefaultComparator<K>();
	}

	public OrderedPQ(Comparator<K> c) {
		comparator = c;
	}

	@Override
	public int size() {
		return size;
	}

	@Override
	public boolean isEmpty() {
		return size == 0;
	}
	
	protected int checkKey(K key) throws IllegalArgumentException{
		try {
			return (comparator.compare(key, key));
		}catch (ClassCastException e) {
			throw new IllegalArgumentException("Invalid Key: "+key);
		}
	}

	@Override
	public Entry<K, V> insert(K key, V value) throws IllegalArgumentException {
		checkKey(key);
		Entry<K,V> entry = new PQEntry<>(key, value);
		Position<Entry<K,V>> i = PQ.last();
		for(Position<Entry<K,V>> j : PQ.positions() ) {
			
		}
		
		return entry;
	}
	
	@Override
	public Entry<K, V> min() {
		if(!isEmpty()) 
			return PQ.first().getElement();
		return null;
	}

	@Override
	public Entry<K, V> removeMin() {
		if(!isEmpty()) 
			return PQ.remove(PQ.first());
		return null;
	}

}
